package entities;

import jakarta.persistence.*;

@Entity
@Table(name = "cards")
public class Card {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "idCard")
    private int idCard;

    @Column(name = "code")
    private String code;

    @Column(name = "type")
    private String type;

    @OneToOne(cascade = CascadeType.ALL, mappedBy = "card") //Como es el lado débil de la relación con Student, hace falta el Cascade aqui
    private Student student; //Como quiero que esté reflejado en la clase Student, no hace falta @JoinColumn (débil)

    public Card(String code, String type) {
        this.code = code;
        this.type = type;
    }

    public Card() {}

    @Override
    public boolean equals(Object obj) {
        return super.equals(obj);
    }

    @Override
    public String toString() {
        return super.toString();
    }
}
