package entities;

import jakarta.persistence.*;

import java.util.List;

@Entity
@Table(name = "students")
public class Student {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "idStudent")
    private int idStudent;

    @Column(name = "name")
    private String name;

    @Column(name = "dni")
    private String dni;

    @Column(name = "phone")
    private String phone;

    @ManyToMany(mappedBy = "student")
    @JoinTable(name="students_courses",
            joinColumns = @JoinColumn(name="idStudent"),
            inverseJoinColumns = @JoinColumn(name="idCourse"))
    private List<Course> courses;

    @OneToOne //Como es el lado fuerte de la relación con Card, no hace falta el Cascade aqui
    @JoinColumn(name = "idCard") //Lado fuerte de la relación con la clase Card
    private Card card;


    public Student(String name, String dni, String phone) {
        this.name = name;
        this.dni = dni;
        this.phone = phone;
    }

    public Student() {}

    @Override
    public boolean equals(Object obj) {



        return super.equals(obj);
    }

    @Override
    public String toString() {



        return super.toString();
    }

}
