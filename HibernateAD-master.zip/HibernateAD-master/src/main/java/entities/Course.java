package entities;

import jakarta.persistence.*;

import java.time.LocalDate;
import java.util.List;

@Entity
@Table(name = "courses")
public class Course {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "idCourse")
    private int idCourse;

    @Column(name = "description")
    private String description;

    @Column(name = "beginDate")
    private LocalDate beginDate;

    @Column(name = "endDate")
    private LocalDate endDate;


    public void setEndDate(LocalDate endDate) {
        this.endDate = endDate;
    }

    public int getIdCourse() {
        return idCourse;
    }

    public String getDescription() {
        return description;
    }

    public LocalDate getBeginDate() {
        return beginDate;
    }

    public LocalDate getEndDate() {
        return endDate;
    }

    public List<Student> getStudents() {
        return students;
    }

    @ManyToMany(mappedBy = "course")
    @JoinTable(name="students_courses",
            joinColumns = @JoinColumn(name="idCourse"),
            inverseJoinColumns = @JoinColumn(name="idStudent"))
    private List<Student> students;


    public Course(String description, LocalDate beginDate) {
        this.description = description;
        this.beginDate = beginDate;
    }

    public Course() {}

    @Override
    public boolean equals(Object obj) {
        return super.equals(obj);
    }

    @Override
    public String toString() {
        return super.toString();
    }

}
